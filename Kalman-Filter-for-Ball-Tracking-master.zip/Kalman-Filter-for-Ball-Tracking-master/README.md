## Kalman-Filter-for-Ball-Tracking 
This Project contains the code for the implementation of Kalman Filter for tracking the pendulum motion of a ball.
Basler's Pylon 500FPS Cameras were used.


